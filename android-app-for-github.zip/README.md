# AM Gateway Connect (Android) - v2
One app for every phone-based provider of your AM Gateway: **FamPay, BharatPe, Manual UPI and bank SMS**.
It reads (1) payment notifications from your payment apps and (2) bank credit SMS, and sends only incoming-money alerts, signed with HMAC-SHA256, to your gateway. Orders are then matched by exact amount + UTR and marked PAID automatically.

## What the merchant does
1. Install the APK.
2. Gateway dashboard (open on the same phone) -> Payment providers -> pick the provider -> enter the UPI ID -> **Create connect link** -> **Open app & connect**.
3. In the app confirm the gateway address, then allow: Notifications, Payment notifications (notification access), SMS, Background. The app opens each screen in turn.
4. The dashboard turns green by itself and the provider switches on. Nothing is copied or pasted. (Other phone: type the address + 8-letter code shown on the dashboard.)

## Build the APK without Android Studio (GitHub Actions)
1. Create a free GitHub repository and upload the **contents of this `android-app` folder** (`gradlew`, `app/`, `.github/` at the repo root).
2. Actions -> *Build APK* -> Run workflow. After ~4 min download artifact `am-sms-forwarder-apk`.
3. Upload the file to the gateway as `downloads/am-sms-forwarder.apk` so merchants get a download button.
Needs JDK 17 + Android SDK 34 if built locally.

## Notes
* Gateway URL must be **https**. The signing secret lives in the app's private storage (backups disabled).
* Heartbeat ~15 min and with every alert. 45 min of silence -> the dashboard stops offering that provider and notifies the merchant.
* Phone date & time must be automatic (a clock more than 10 min off is rejected).
* Android 13+ blocks some permissions for apps installed from an APK: App settings -> top-right menu -> **Allow restricted settings**, then grant again.
* Privacy: a notification is read only when its app package is on the gateway's list AND its text looks like incoming money. Everything else is ignored on the spot, never stored or sent.
* This source was written without an Android SDK available, so it has not been compiled yet. If the first Gradle build shows an error, send it - it will be a one-line fix.
