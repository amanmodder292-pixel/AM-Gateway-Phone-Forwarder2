package com.amgateway.smsforwarder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Keeps the gateway connection alive in the background (foreground service with a small silent notification).
 * Every 4 minutes it sends the queued alerts and a heartbeat, so the dashboard shows the phone as ONLINE all day and night,
 * even when Android's battery saver would otherwise delay the 15-minute background job.
 */
class KeepAliveService : Service() {
    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    private val tick = object : Runnable {
        override fun run() {
            try {
                val p = Prefs(applicationContext)
                if (!p.isPaired) { stopSelf(); return }
                Uploader.flush(applicationContext)
                Uploader.ping(applicationContext)
            } catch (e: Exception) { /* keep running */ }
            handler?.postDelayed(this, INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        goForeground()
        thread = HandlerThread("amg-keepalive").also { it.start() }
        handler = Handler(thread!!.looper).also { it.post(tick) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Gateway connection", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
            .setContentTitle("AM Gateway is running")
            .setContentText("Watching for payment alerts - keep this on")
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(NOTIF_ID, n)
    }

    companion object {
        private const val CHANNEL = "amg_keepalive"
        private const val NOTIF_ID = 4401
        private const val INTERVAL_MS = 4 * 60 * 1000L

        /** safe to call from anywhere; does nothing before pairing and never crashes if Android refuses a background start */
        fun start(ctx: Context) {
            try {
                if (!Prefs(ctx.applicationContext).isPaired) return
                ContextCompat.startForegroundService(ctx.applicationContext, Intent(ctx.applicationContext, KeepAliveService::class.java))
            } catch (e: Exception) { /* e.g. started from background - it will start next time the app is opened */ }
        }
    }
}
